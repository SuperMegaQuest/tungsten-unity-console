﻿using UnityEngine;

public delegate Vector3 GraphFunction(float u, float v, float t);